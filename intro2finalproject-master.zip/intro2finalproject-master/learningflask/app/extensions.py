from flask_wtf import CsrfProtect

csrf = CsrfProtect()
